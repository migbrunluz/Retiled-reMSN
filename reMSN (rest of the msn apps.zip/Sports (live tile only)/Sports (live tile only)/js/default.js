﻿(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var notifications = Windows.UI.Notifications;


    var sportsInterestIds = {
        "en-us": "Y_b09e3e40-000d-454d-87ef-96631d7c9e7c",
        "en-gb": "Y_0dc850ed-9a73-4d87-ad50-362e490b9ded",
        "en-au": "Y_ec840236-5b86-4416-9d1b-4651f91c07d9",
        "en-ca": "Y_ef1acff0-b8c0-4def-8445-fbf4db1d7050",
        "en-in": "Y_0d4b411d-7d62-430d-9bdf-ac39c0b27d51",
        "en-nz": "Y_74828980-cea7-4d76-a3a4-08bc3649ce0d",
        "en-za": "Y_d424db2b-bb2e-4349-b21a-9adc072c1a69",
        "en-sg": "Y_5467a533-93ff-43a2-89a5-1c29700e0992",
        "en-ph": "Y_253d3f8e-a309-4687-aae3-9954ef161615",
        "en-my": "Y_42101e83-d182-4e57-b0a3-0f4c513294b5",
        "fr-ca": "Y_d74a2001-bed4-4af7-9c16-e733acaab543",
        "fr-be": "Y_77b69adb-3820-4264-8aeb-be8cc67a3a2d",
        "de-de": "Y_053f993f-d476-48f4-958a-90c43807851e",
        "de-at": "Y_da62fa96-52cb-4135-85a8-2fe7d2f11dab",
        "es-es": "Y_7c4522f7-37dd-4a14-989a-7cb97aca5479",
        "es-mx": "Y_3651bbd2-2497-4a00-9f87-c4c1414d7f3d",
        "es-co": "Y_6810c983-c1c4-44b7-a68a-678799b0b4ab",
        "es-cl": "Y_781ab3e2-586a-47b2-a9b7-3ba84dd15f90",
        "es-pe": "Y_c1ae10bd-d3cc-4249-84d4-83564717f63e",
        "es-ve": "Y_c9499db0-ead6-4ad6-b6ee-132ded3db9e8",
        "es-xl": "Y_3a9f44a1-94a1-42b5-9fd4-a361c5fed810",
        "pt-pt": "Y_a44d2906-1f91-4a0b-bfbb-dfb4f3fa1027",
        "pt-br": "Y_dd939fa7-ea85-4757-bd2d-5b0914156c83",
        "it-it": "Y_0a662755-a2c0-49f1-bdcd-56268091f0cd",
        "nl-nl": "Y_1bd36d42-6d1d-41e8-ab34-9a71de104cf2",
        "nl-be": "Y_3d1888d1-3db4-4ecd-8690-5d9b35e13b8b",
        "sv-se": "Y_9605265b-e69f-4e8a-915c-aa7185d2ead2",
        "da-dk": "Y_639e086e-b9ac-4f21-a85c-bb568513fae8",
        "pl-pl": "Y_800c71ee-fd4e-44ab-9658-20a0652a969c",
        "tr-tr": "Y_a88ebbe2-e55f-4304-a672-f15d336345ba",
        "ja-jp": "Y_f8e693e5-f161-4021-afc0-f1bd31b95a23",
        "ko-kr": "Y_bc40ffcd-5e18-475c-8752-cb7ca85085a9",
        "zh-cn": "Y_da8de783-28cd-4248-9b12-ca42f01520ff",
        "zh-tw": "Y_efcc27a6-603c-42e3-8801-13457053eed3",
        "zh-hk": "Y_616aa423-4ff2-40ab-9514-252af32beb78",
        "ar-eg": "Y_8a197af8-97c0-48a4-840c-aaed9b9671d0",
        "ar-ae": "Y_0a18cbfd-d2c4-4d75-b464-0e460f77d4dc",
        "vi-vn": "Y_5cede9ba-2e58-4019-9750-994ba032868d",
        "cs-cz": "Y_1321e05f-cf64-4a6d-9ba6-1631386c89fa",
        "hu-hu": "Y_e03530ec-1641-4404-8766-68cd849e39de"
    };

    function getInterestId(lang) {
        lang = lang.toLowerCase();
        return sportsInterestIds[lang] || sportsInterestIds["en-us"];
    }

    function fetchSportsFeed(interestId, langcode) {
        var url = new Windows.Foundation.Uri("https://assets.msn.com/service/news/feed");
        var client = new Windows.Web.Http.HttpClient();
        var uriBuilder = new Windows.Foundation.Uri(url +
            "?activityId=791903AE-0A52-46F5-9EC1-4ABBA381ACEA" +
            "&apikey=kO1dI4ptCTTylLkPL1ZTHYP8JhLKb8mRDoA5yotmNJ" +
            "&cm=" + encodeURIComponent(langcode) +
            "&contentType=article" +
            "&ids=" + encodeURIComponent(interestId) +
            "&infopaneCount=0" +
            "&it=web" +
            "&market=" + encodeURIComponent(langcode) +
            "&ocid=sports-vertical-landing" +
            "&queryType=myFeed" +
            "&scn=ANON" +
            "&skip=0" +
            "&timeOut=3000" +
            "&top=8" +
            "&user=m-31438E9A21C9613A37BC9B2C209E6070"
        );

        return client.getAsync(uriBuilder).then(function (response) {
            return response.content.readAsStringAsync();
        }).then(function (text) {
            return JSON.parse(text);
        });
    }

    function extractFirstArticle(json) {
        function getInfo(card) {
            if (card.type === "article") {
                var title = card.title || "Notícia";
                var image = (card.images && card.images.length > 0) ? card.images[0].url : "";
                return { title: title, image: image };
            }
            return null;
        }

        for (var i = 0; i < json.value.length; i++) {
            var card = json.value[i];
            var result = getInfo(card);
            if (result) return result;

            if (card.subCards) {
                for (var j = 0; j < card.subCards.length; j++) {
                    result = getInfo(card.subCards[j]);
                    if (result) return result;
                }
            }
        }
        return { title: "Sem notícias", image: "" };
    }

    function escapeXml(str) {
        return str.replace(/&/g, "&amp;")
                  .replace(/</g, "&lt;")
                  .replace(/>/g, "&gt;")
                  .replace(/"/g, "&quot;")
                  .replace(/'/g, "&apos;");
    }

    function updateTile(article, langcode) {
        var title = escapeXml(article.title || "News");

        // Optional: allow separate images per size if available in article
        var imageSmall = escapeXml(article.imageSmall || article.image || "");
        var imageWide = escapeXml(article.imageWide || article.image || "");
        var imageLarge = escapeXml(article.imageLarge || article.image || "");

        var tileXmlString =
            '<tile>' +
            '<visual version="2" lang="' + langcode + '">' +

            // Square 150x150 Peek template
            '<binding template="TileSquare150x150PeekImageAndText04" fallback="TileSquarePeekImageAndText04">' +
            '<image id="1" src="' + imageSmall + '" alt=""/>' +
            '<text id="1">' + title + '</text>' +
            '</binding>' +

            // Wide 310x150
            '<binding template="TileWide310x150ImageAndText01" fallback="TileWideImageAndText01">' +
            '<image id="1" src="' + imageWide + '" alt=""/>' +
            '<text id="1">' + title + '</text>' +
            '</binding>' +

            // Square 310x310
            '<binding template="TileSquare310x310ImageAndText01">' +
            '<image id="1" src="' + imageLarge + '" alt=""/>' +
            '<text id="1">' + title + '</text>' +
            '</binding>' +

            '</visual>' +
            '</tile>';

        var tileDOM = new Windows.Data.Xml.Dom.XmlDocument();
        try {
            tileDOM.loadXml(tileXmlString);
            var tileNotification = new Windows.UI.Notifications.TileNotification(tileDOM);
            var updater = Windows.UI.Notifications.TileUpdateManager.createTileUpdaterForApplication();
            updater.clear();
            updater.update(tileNotification);
        } catch (e) {
            console.error("Tile XML Error: " + e.message + "\n\nXML:\n" + tileXmlString);
        }
    }

    function refreshTile(langcode, interestId) {
        fetchSportsFeed(interestId, langcode).then(function (json) {
            var article = extractFirstArticle(json);
            updateTile(article, langcode);
        }, function (err) {
            console.error("Failed to refresh tile:", err);
        });
    }

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            args.setPromise(WinJS.UI.processAll().then(function () {
                var langcode = Windows.Globalization.Language.currentInputMethodLanguageTag;
                var interestId = getInterestId(langcode);

                // Initial tile update
                refreshTile(langcode, interestId);

                // Setup recurring update every 30 minutes (1800000 ms)
                setInterval(function () {
                    refreshTile(langcode, interestId);
                }, 30 * 60 * 1000); // 30 minutes
            }));
        }
    };

    app.oncheckpoint = function (args) {
        // You can save app state here if needed.
    };

    app.start();
})();