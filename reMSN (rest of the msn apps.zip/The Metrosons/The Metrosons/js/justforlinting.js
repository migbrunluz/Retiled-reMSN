﻿(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var notifications = Windows.UI.Notifications;

    // Locale to Interest ID map
    var interestMap = {
        "en-us": "Y_46b78bbb-31c4-4fc5-8a4a-858072348d06",
        "en-gb": "Y_ee0f77da-0986-43aa-8ec3-5d2e685d4b86",
        "en-au": "Y_ac7ca585-795f-47ab-9ef1-6d4e78eb1297",
        "en-ca": "Y_6800df35-28cf-4dc2-ba3f-11038cc932ef",
        "en-in": "Y_0b495ad3-9beb-45f8-9214-c8e95aa2468f",
        "fr-fr": "Y_b43a59b1-5014-48d4-be06-75d3cf7da630",
        "de-de": "Y_a8f70a0a-bd27-48ab-8843-0845227b72e3",
        "es-es": "Y_41e211a7-2048-4449-b081-37f8c5e84daa",
        "pt-br": "Y_fdac555d-4ec2-428a-88e4-cb891ca7d5e9",
        "zh-cn": "Y_321db332-7d5a-4672-96b5-2d342ca554fb"
        // Add more if needed
    };

    var lang = (navigator.language || "en-us").toLowerCase();
    var interest = interestMap[lang] || interestMap["en-us"];

    var msnApiUrl = "https://api.msn.com:443/news/feed/pages/channelfeed?" +
        "activityId=38A085DC-3C51-41B7-A36F-19030D0F56A8" +
        "&timeOut=10000&scn=ANON" +
        "&apikey=0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM" +
        "&User=m-00F1EE5495926F9315A5F85194C56EAA" +
        "&newsSkip=24&$skip=1" +
        "&cm=" + encodeURIComponent(lang);

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            args.setPromise(
                WinJS.UI.processAll().then(function () {
                    return loadNewsAndUpdateTiles();
                })
            );
        }
    };

    app.start();

    function loadNewsAndUpdateTiles() {
        return WinJS.xhr({ url: msnApiUrl }).then(function (response) {
            var data = JSON.parse(response.responseText);

            if (!data || typeof data !== "object") {
                console.warn("Invalid data format");
                return;
            }

            var sections = data.sections || [];
            if (!Array.isArray(sections) || !sections.length) {
                console.warn("No 'sections' found.");
                return;
            }

            var cards = sections[0].cards || [];
            if (!Array.isArray(cards) || !cards.length) {
                console.warn("No 'cards' found.");
                return;
            }

            var articles = [];

            cards.forEach(function (card) {
                if (!card || typeof card !== "object") return;
                var title = card.title || "Untitled";
                var images = Array.isArray(card.images) ? card.images : [];
                var img = images.length ? images[0].url : "";
                articles.push({
                    title: title,
                    description: card.snippet || "",
                    urlToImage: img
                });
            });

            if (articles.length === 0) {
                console.warn("No valid articles.");
                return;
            }

            updateTiles(articles.slice(0, 4));
            showToasts(articles.slice(0, 4));
        }, function (error) {
            console.error("MSN fetch failed:", error);
        });
    }

    function createXmlFromString(xmlString) {
        var xmlDoc = new Windows.Data.Xml.Dom.XmlDocument();
        try {
            xmlDoc.loadXml(xmlString);
        } catch (e) {
            console.error("XML parse error:", e, xmlString);
            throw e;
        }
        return xmlDoc;
    }

    function sanitizeUrl(url) {
        return url ? url.replace(/[\x00-\x20]/g, "") : "";
    }

    function escapeXml(str) {
        return str ? str.replace(/[<>&'"]/g, function (c) {
            return {
                '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;'
            }[c];
        }) : "";
    }

    function updateTiles(articles) {
        var updater = notifications.TileUpdateManager.createTileUpdaterForApplication();
        updater.enableNotificationQueue(true);
        updater.clear();

        // ARTICLE 1: Image + text templates (PeekImageAndText + ImageAndText)
        if (articles[0]) {
            var a1 = articles[0];
            var tileXmlStr1 =
                '<tile>' +
                    '<visual version="2" lang="en-US">' +
                        '<binding template="TileSquare150x150PeekImageAndText04" fallback="TileSquarePeekImageAndText04">' +
                            '<image id="1" src="' + escapeXml(sanitizeUrl(a1.urlToImage)) + '" alt=""/>' +
                            '<text id="1">' + escapeXml(a1.title) + '</text>' +
                        '</binding>' +
                        '<binding template="TileWide310x150ImageAndText01" fallback="TileWideImageAndText01">' +
                            '<image id="1" src="' + escapeXml(sanitizeUrl(a1.urlToImage)) + '" alt=""/>' +
                            '<text id="1">' + escapeXml(a1.title) + '</text>' +
                        '</binding>' +
                        '<binding template="TileSquare310x310ImageAndText01">' +
                            '<image id="1" src="' + escapeXml(sanitizeUrl(a1.urlToImage)) + '" alt=""/>' +
                            '<text id="1">' + escapeXml(a1.title) + '</text>' +
                        '</binding>' +
                    '</visual>' +
                '</tile>';

            var tileXml1 = createXmlFromString(tileXmlStr1);
            updater.update(new notifications.TileNotification(tileXml1));
        }

        // ARTICLE 2 & 3: Text-only templates with lists
        if (articles[1] && articles[2]) {
            var a2 = articles[1];
            var a3 = articles[2];
            var tileXmlStr2 =
                '<tile>' +
                    '<visual version="2" lang="en-US">' +
                        '<binding template="TileSquare150x150Text04" fallback="TileSquareText04" branding="name">' +
                            '<text id="1">' + escapeXml(a2.title) + '</text>' +
                        '</binding>' +
                        '<binding template="TileWide310x150Text04" fallback="TileWideText04" branding="name">' +
                            '<text id="1">' + escapeXml(a2.title) + '</text>' +
                        '</binding>' +
                        '<binding template="TileSquare310x310TextList02" contentId="461840954" branding="name">' +
                            '<text id="1">' + escapeXml(a2.title) + '</text>' +
                            '<text id="2">' + escapeXml(a3.title) + '</text>' +
                            '<text id="3">' + escapeXml(articles[3] ? articles[3].title : "") + '</text>' +
                        '</binding>' +
                    '</visual>' +
                '</tile>';

            var tileXml2 = createXmlFromString(tileXmlStr2);
            updater.update(new notifications.TileNotification(tileXml2));
        }

        // ARTICLE 4: Mixed text + image templates
        if (articles[3]) {
            var a4 = articles[3];
            var tileXmlStr3 =
                '<tile>' +
                    '<visual version="2" lang="en-US">' +
                        '<binding template="TileSquare150x150Text04" fallback="TileSquareText04" branding="name">' +
                            '<text id="1">' + escapeXml(a4.title) + '</text>' +
                        '</binding>' +
                        '<binding template="TileWide310x150SmallImageAndText03" fallback="TileWideSmallImageAndText03" branding="name">' +
                            '<image id="1" src="' + escapeXml(sanitizeUrl(a4.urlToImage)) + '" alt=""/>' +
                            '<text id="1">' + escapeXml(a4.title) + '</text>' +
                        '</binding>' +
                        '<binding template="TileSquare310x310TextList02" contentId="461840954" branding="name">' +
                            '<text id="1">' + escapeXml(articles[1].title) + '</text>' +
                            '<text id="2">' + escapeXml(articles[2].title) + '</text>' +
                            '<text id="3">' + escapeXml(a4.title) + '</text>' +
                        '</binding>' +
                    '</visual>' +
                '</tile>';

            var tileXml3 = createXmlFromString(tileXmlStr3);
            updater.update(new notifications.TileNotification(tileXml3));
        }

        console.log("Tiles updated with news articles");
    }

    function showToasts(articles) {
        articles.forEach(function (article) {
            var title = escapeXml(article.title);
            var description = escapeXml(article.description || "");
            var img = article.urlToImage ? sanitizeUrl(article.urlToImage) : "";

            var toastXmlStr =
                `<toast>
                    <visual>
                        <binding template="ToastGeneric">
                            <text>${title}</text>
                            <text>${description}</text>
                            ${img ? `<image placement="appLogoOverride" src="${img}" />` : ""}
                        </binding>
                    </visual>
                </toast>`;

            var toastXml = createXmlFromString(toastXmlStr);
            var toast = new notifications.ToastNotification(toastXml);
            notifications.ToastNotificationManager.createToastNotifier().show(toast);
        });

        console.log("Toasts shown.");
    }
})();
