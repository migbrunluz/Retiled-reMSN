﻿(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var language = Windows.Globalization.ApplicationLanguages.languages[0] || "en-US";

    // ---- MSN Feed Tile (image + text), cycles every 30 mins through top 30 articles ----
    var msnFeedUrlBase = "https://assets.msn.com/service/MSN/Feed/me?$top=30&DisableTypeSerialization=true" +
        "&activityId=87DF52CC-44F1-410E-A0DF-100FD91AC9F1" +
        "&apikey=0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM" +
        "&cm=" + language +
        "&contentType=article&it=web&query=finance_latest&queryType=myfeed" +
        "&responseSchema=cardview&scn=ANON&timeOut=2000" +
        "&user=m-31438E9A21C9613A37BC9B2C209E6070&wrapodata=false";

    var msnArticles = [];
    var msnArticleIndex = 0;

    function escapeXml(str) {
        if (!str) return '';
        return str.replace(/[<>&'"]/g, function (c) {
            return {
                '<': '&lt;',
                '>': '&gt;',
                '&': '&amp;',
                '\'': '&apos;',
                '"': '&quot;'
            }[c];
        });
    }

    function buildMsnTileXml(title, imageUrl) {
        return '<?xml version="1.0" encoding="utf-8"?>' +
            '<tile>' +
            '<visual version="2" lang="' + language + '">' +

            '<binding template="TileSquare150x150PeekImageAndText04" fallback="TileSquarePeekImageAndText04">' +
            '<image id="1" src="' + escapeXml(imageUrl) + '" alt=""/>' +
            '<text id="1">' + escapeXml(title) + '</text>' +
            '</binding>' +

            '<binding template="TileWide310x150ImageAndText01" fallback="TileWideImageAndText01">' +
            '<image id="1" src="' + escapeXml(imageUrl) + '" alt=""/>' +
            '<text id="1">' + escapeXml(title) + '</text>' +
            '</binding>' +

            '<binding template="TileSquare310x310ImageAndText01">' +
            '<image id="1" src="' + escapeXml(imageUrl) + '" alt=""/>' +
            '<text id="1">' + escapeXml(title) + '</text>' +
            '</binding>' +

            '</visual>' +
            '</tile>';
    }

    function updateMsnFeedTile() {
        if (msnArticles.length === 0) {
            // Fetch articles list first
            WinJS.xhr({ url: msnFeedUrlBase }).then(function (response) {
                var json = JSON.parse(response.responseText);
                msnArticles = json.subCards || [];
                msnArticleIndex = 0;
                showNextMsnArticle();
            }, function (err) {
                console.error("Failed to fetch MSN feed:", err);
            });
        } else {
            showNextMsnArticle();
        }
    }

    function showNextMsnArticle() {
        if (msnArticles.length === 0) return;

        var article = msnArticles[msnArticleIndex];
        var title = article.title || "MSN Finance";
        var imageUrl = (article.images && article.images.length > 0) ? article.images[0].url : "";

        var tileXml = new Windows.Data.Xml.Dom.XmlDocument();
        try {
            tileXml.loadXml(buildMsnTileXml(title, imageUrl));
            var notification = new Windows.UI.Notifications.TileNotification(tileXml);
            Windows.UI.Notifications.TileUpdateManager.createTileUpdaterForApplication().update(notification);
        } catch (e) {
            console.error("Error updating MSN feed tile:", e);
        }

        msnArticleIndex = (msnArticleIndex + 1) % msnArticles.length;
    }

    // ---- Yahoo Finance Chart Tile, cycles every 30 mins through symbols with chart images ----
    var yahooSymbols = [
        { symbol: "^DJI", name: "DOW" },
        { symbol: "^IXIC", name: "NASDAQ" },
        { symbol: "^GSPC", name: "S&P 500" }
    ];
    var yahooCurrentIndex = 0;

    function fetchYahooChart(symbol, callback) {
        var url = "https://query1.finance.yahoo.com/v8/finance/chart/" +
            encodeURIComponent(symbol) +
            "?range=1d&interval=5m&includePrePost=false";

        WinJS.xhr({ url: url }).then(function (r) {
            var json = JSON.parse(r.responseText);
            if (!json.chart || !json.chart.result || !json.chart.result[0]) {
                callback(null);
                return;
            }
            var res = json.chart.result[0];
            var close = res.indicators.quote[0].close;
            var ts = res.timestamp;
            var last = close[close.length - 1];
            var first = close[0];
            var change = last - first;
            var pct = (change / first) * 100;
            var now = new Date(ts[ts.length - 1] * 1000).toLocaleTimeString(language, { hour: '2-digit', minute: '2-digit' });

            callback({
                symbol: symbol,
                name: yahooSymbols[yahooCurrentIndex].name,
                price: last.toFixed(2),
                change: (change >= 0 ? "+" : "") + change.toFixed(2) + " (" + pct.toFixed(2) + "%)",
                time: now,
                series: { timestamps: ts, closes: close }
            });
        }, function () {
            callback(null);
        });
    }

    function drawChartToFile(data, size, filename, callback) {
        var canvas = document.createElement("canvas");
        var dims = { medium: 150, wideW: 310, wideH: 150, large: 310 };
        if (size === "medium") {
            canvas.width = dims.medium;
            canvas.height = dims.medium;
        } else if (size === "wide") {
            canvas.width = dims.wideW;
            canvas.height = dims.wideH;
        } else {
            canvas.width = dims.large;
            canvas.height = dims.large;
        }

        var ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = "#FFFFFF";
        ctx.lineWidth = 2;
        ctx.beginPath();

        var closes = data.series.closes;
        if (!closes || closes.length === 0) {
            callback(null);
            return;
        }

        var minP = Math.min.apply(null, closes);
        var maxP = Math.max.apply(null, closes);
        for (var i = 0; i < closes.length; i++) {
            var x = (i / (closes.length - 1)) * canvas.width;
            var y = canvas.height - ((closes[i] - minP) / (maxP - minP)) * canvas.height;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.stroke();

        // msToBlob for IE/Edge
        var blob = canvas.msToBlob ? canvas.msToBlob() : null;
        if (!blob) {
            callback(null);
            return;
        }

        Windows.Storage.ApplicationData.current.localFolder.createFileAsync(filename, Windows.Storage.CreationCollisionOption.replaceExisting)
            .then(function (file) {
                return file.openAsync(Windows.Storage.FileAccessMode.readWrite).then(function (stream) {
                    var reader = new FileReader();
                    reader.onloadend = function () {
                        var inputBytes = new Uint8Array(reader.result);
                        var writer = new Windows.Storage.Streams.DataWriter(stream);
                        writer.writeBytes(inputBytes);
                        writer.storeAsync().done(function () {
                            writer.close();
                            stream.close();
                            callback("ms-appdata:///local/" + filename);
                        });
                    };
                    reader.readAsArrayBuffer(blob);
                });
            });
    }

    function buildYahooTileXml(params) {
        return '<?xml version="1.0" encoding="utf-8"?>' +
            '<tile><visual version="2" lang="' + language + '">' +
            '<binding template="TileSquare150x150PeekImageAndText04" fallback="TileSquarePeekImageAndText04">' +
            '<image id="1" src="' + params.imgMedium + '" alt=""/>' +
            '<text id="1">' + params.text + '</text>' +
            '</binding>' +
            '<binding template="TileWide310x150ImageAndText02" fallback="TileWideImageAndText02">' +
            '<image id="1" src="' + params.imgWide + '" alt=""/>' +
            '<text id="1">' + params.name + ' - ' + params.time + '</text>' +
            '<text id="2">' + params.price + '  ' + params.change + '</text>' +
            '</binding>' +
            '<binding template="TileSquare310x310ImageAndText02">' +
            '<image id="1" src="' + params.imgLarge + '" alt=""/>' +
            '<text id="1">' + params.name + ' - ' + params.time + '</text>' +
            '<text id="2">' + params.price + '  ' + params.change + '</text>' +
            '</binding>' +
            '</visual></tile>';
    }

    function updateYahooChartTile() {
        var symbol = yahooSymbols[yahooCurrentIndex].symbol;
        fetchYahooChart(symbol, function (data) {
            if (!data) return;
            drawChartToFile(data, "medium", "chart_medium.png", function (imgMedium) {
                drawChartToFile(data, "wide", "chart_wide.png", function (imgWide) {
                    drawChartToFile(data, "large", "chart_large.png", function (imgLarge) {
                        var params = {
                            imgMedium: imgMedium,
                            imgWide: imgWide,
                            imgLarge: imgLarge,
                            name: data.name,
                            time: data.time,
                            price: data.price,
                            change: data.change,
                            text: data.name + " " + data.time
                        };

                        var tileXml = new Windows.Data.Xml.Dom.XmlDocument();
                        try {
                            tileXml.loadXml(buildYahooTileXml(params));
                            Windows.UI.Notifications.TileUpdateManager.createTileUpdaterForApplication().update(
                                new Windows.UI.Notifications.TileNotification(tileXml)
                            );
                        } catch (e) {
                            console.error("Error updating Yahoo tile:", e.message);
                        }

                        // Cycle to next symbol for next update
                        yahooCurrentIndex = (yahooCurrentIndex + 1) % yahooSymbols.length;
                    });
                });
            });
        });
    }

    // ---- Stocks/Commodities Ticker Text Tile, switches every 10s, swaps stocks/commodities every 20s ----
    var stocks = [
        { symbol: "^DJI", name: "DOW" },
        { symbol: "^FTSE", name: "FTSE 100" },
        { symbol: "^N225", name: "NIKKEI 225" }
    ];
    var commodities = [
        { symbol: "GC=F", name: "Gold" },
        { symbol: "CL=F", name: "Crude oil" },
        { symbol: "SI=F", name: "Silver" }
    ];
    var showingStocks = true;
    var tickerRefreshCount = 0;

    function buildTickerTileXml(items) {
        return '<?xml version="1.0" encoding="utf-8"?>' +
            '<tile>' +
            '<visual version="2" lang="' + language + '">' +

            '<binding template="TileSquare310x310TextList01" branding="logo">' +
            '<text id="1">' + escapeXml(items[0].label) + '</text>' +
            '<text id="2">' + escapeXml(items[0].detail) + '</text>' +
            '<text id="3">' + escapeXml(items[0].time) + '</text>' +
            '<text id="4">' + escapeXml(items[1].label) + '</text>' +
            '<text id="5">' + escapeXml(items[1].detail) + '</text>' +
            '<text id="6">' + escapeXml(items[1].time) + '</text>' +
            '<text id="7">' + escapeXml(items[2].label) + '</text>' +
            '<text id="8">' + escapeXml(items[2].detail) + '</text>' +
            '<text id="9">' + escapeXml(items[2].time) + '</text>' +
            '</binding>' +

            '<binding template="TileWide310x150Text08" branding="name">' +
            '<text id="1">' + escapeXml(items[0].name) + '</text>' +
            '<text id="2">' + escapeXml(items[0].label.split(' ')[0] + " " + items[0].detail.split(' ')[0]) + '</text>' +
            '<text id="3">' + escapeXml(items[1].name) + '</text>' +
            '<text id="4">' + escapeXml(items[1].label.split(' ')[0] + " " + items[1].detail.split(' ')[0]) + '</text>' +
            '<text id="5">' + escapeXml(items[2].name) + '</text>' +
            '<text id="6">' + escapeXml(items[2].label.split(' ')[0] + " " + items[2].detail.split(' ')[0]) + '</text>' +
            '</binding>' +

            '<binding template="TileSquare150x150Text03" branding="name">' +
            '<text id="1">' + escapeXml(items[0].label) + '</text>' +
            '<text id="2">' + escapeXml(items[1].label) + '</text>' +
            '<text id="3">' + escapeXml(items[2].label) + '</text>' +
            '</binding>' +

            '</visual>' +
            '</tile>';
    }

    function updateTickerTile(data) {
        if (!data) return;
        var tileXml = new Windows.Data.Xml.Dom.XmlDocument();
        try {
            tileXml.loadXml(buildTickerTileXml(data));
            Windows.UI.Notifications.TileUpdateManager.createTileUpdaterForApplication().update(
                new Windows.UI.Notifications.TileNotification(tileXml)
            );
        } catch (e) {
            console.error("Error updating ticker tile:", e);
        }
    }

    function fetchChartForTicker(item) {
        var url = "https://query1.finance.yahoo.com/v8/finance/chart/" + encodeURIComponent(item.symbol) +
            "?range=1d&interval=5m&includePrePost=false";

        return WinJS.xhr({ url: url }).then(function (response) {
            var json = JSON.parse(response.responseText);
            var result = json.chart.result[0];
            var close = result.indicators.quote[0].close;
            var timestamps = result.timestamp;
            var lastPrice = close[close.length - 1];
            var openPrice = close[0];
            var change = lastPrice - openPrice;
            var changePercent = (change / openPrice) * 100;

            var dirSymbol = (change >= 0) ? "▲" : "▼";
            var now = new Date(timestamps[timestamps.length - 1] * 1000).toLocaleString(language, { timeZoneName: 'short' });

            return {
                label: dirSymbol + " " + item.name,
                name: item.name,
                detail: lastPrice.toFixed(2) + " " +
                    (change >= 0 ? "+" : "") + change.toFixed(2) +
                    " (" + changePercent.toFixed(2) + "%)",
                time: now
            };
        }, function () {
            return {
                label: "",
                name: item.name,
                detail: "N/A",
                time: ""
            };
        });
    }

    function updateStocksCommoditiesTicker() {
        var currentItems = showingStocks ? stocks : commodities;
        var promises = currentItems.map(fetchChartForTicker);

        WinJS.Promise.join(promises).then(function (results) {
            updateTickerTile(results);

            tickerRefreshCount++;
            if (tickerRefreshCount >= 2) {
                showingStocks = !showingStocks;
                tickerRefreshCount = 0;
            }
        }, function (err) {
            console.error("Ticker update error:", err);
        });
    }

    // --- Activation & timers ---
    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            args.setPromise(WinJS.UI.processAll().then(function () {
                // Initial calls:
                updateMsnFeedTile();
                updateYahooChartTile();
                updateStocksCommoditiesTicker();

                // Timers:
                setInterval(updateMsnFeedTile, 30 * 60 * 1000);       // every 30 minutes
                setInterval(updateYahooChartTile, 30 * 60 * 1000);    // every 30 minutes
                setInterval(updateStocksCommoditiesTicker, 10 * 1000); // every 10 seconds
            }));
        }
    };

    app.start();

})();

